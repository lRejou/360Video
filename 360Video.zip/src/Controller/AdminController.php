<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Video;
use App\Repository\VideoRepository;

/**
 * @Route("/admin")
 */
class AdminController 
{
    /**
     * @Route("/", name="index", methods={"GET"})
     */
    public function index(): Response
    {
        return new Response($this->twig->render('admin/home.html.twig'));
    }

    /**
     * @Route("/videos", name="video", methods={"GET"})
     */
    public function video(): Response
    {
        return new Response($this->twig->render('admin/video.html.twig'));
    }

}